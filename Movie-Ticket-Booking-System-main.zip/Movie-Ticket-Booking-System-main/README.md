# Movie Ticket Booking System
 The main aim of project is to book cinema tickets online. User interface is designed in Angular integrated with Java Spring boot APIs with MySQL in the back-end. Latest schedule and details of all the movies and theatres are maintained in the database. User can select seat of his choice in any theatre and book the ticket accordingly.
