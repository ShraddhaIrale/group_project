export class Booking
{

    bookingid:number;
    noofseats:number;
    userid:number;
    showid:number;
    status:string;  //enum
    timestamp : Date;

}
