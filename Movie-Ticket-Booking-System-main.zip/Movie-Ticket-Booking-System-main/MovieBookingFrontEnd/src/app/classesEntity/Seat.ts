export class Seat
{

    seatid:number;
    seatnumber:string;
    type:string;        //enum
    screenid:string;

}
