export class Movie
{

    movieid:number;
    title:string;
    description :string;
    type:string;          //enum
    genre :string;
    duration: Date;
    releasedate:Date;

}
