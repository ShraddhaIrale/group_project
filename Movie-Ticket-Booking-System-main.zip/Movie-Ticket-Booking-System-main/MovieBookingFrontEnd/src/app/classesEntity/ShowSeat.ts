export class ShowSeat
{

    showseatid:number;
    status :string;    //enum
    price:number;
    showid:number;
    bookingid:number;
    seatid:number;



  }

