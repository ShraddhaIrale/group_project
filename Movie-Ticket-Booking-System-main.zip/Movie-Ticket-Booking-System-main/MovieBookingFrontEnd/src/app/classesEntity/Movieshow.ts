import { Time } from "@angular/common";

export class Movieshow
{

    showid:number;
    date:Date;
    starttime:Time;
    endtime:Time;
    screenid:string;
    movieid:number;

}
