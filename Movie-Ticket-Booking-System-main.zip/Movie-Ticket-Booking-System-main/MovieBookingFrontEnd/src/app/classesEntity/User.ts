export class User{
      userId:number;
      username:string;
      userpassword:string;
      email:string;
      phone:string;

}
