User and City queries :



insert into user (userid,email, phone, username, password) values (100,"a@b.c","9988776655","user1","user123");
insert into user (userid,email, phone, username, password) values (200,"b@b.c","9988776655","user2","user123");
insert into user (userid,email, phone, username, password) values (300,"c@b.c","9988776655","user3","user123");




insert into city ( zipcode, cityname , state ) values ( 425412 , "Nandurbar" , "Maharashtra"  );
insert into city ( zipcode, cityname , state ) values ( 422003 , "Nashik" , "Maharashtra"  );
insert into city ( zipcode, cityname , state ) values ( 556644 , "Lucknow" , "Uttar Pradesh"  );
insert into city ( zipcode, cityname , state ) values ( 136118, "Kurukshetra" , "Haryana"  );
insert into city ( zipcode, cityname , state ) values ( 530068 , "Bangalore" , "Karnataka"  );
insert into city ( zipcode, cityname , state ) values ( 11096, "Noida" , " Uttar Pradesh "  );
insert into city ( zipcode, cityname , state ) values ( 403001 , "Panji" , " Goa "  );
insert into city ( zipcode, cityname , state ) values ( 222001 , "Jaunpur" , "Uttar Pradesh"  );
insert into city ( zipcode, cityname , state ) values ( 447236 , "Mumbai" , "Maharashtra"  );
insert into city ( zipcode, cityname , state ) values ( 425412 , "Chandani Chauk" , "Delhi"  );
insert into city ( zipcode, cityname , state ) values ( 332576 , "Goregaav" , "Maharashtra"  );
insert into city ( zipcode, cityname , state ) values ( 234514 , "Ayodhya" , "Uttar Pradesh"  );
insert into city ( zipcode, cityname , state ) values ( 287645 , "Ahemdabad" , "Gujrat"  );


